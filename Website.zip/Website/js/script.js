var content = new Array();
content[0] = new Array("The food is amazing", "Wallace, Brookyln","1");
content[1] = new Array("It's so cheap to shop there", "Mary, Europe", "2");
content[2] = new Array("I'm delighted by the service:)", "Tom, Japan", "3");
content[3] = new Array("It is the best!", "Kevin, Singapornew Arraye", "4");
content[4] = new Array("Night life's the secret", "Theresa, Australia", "5");
content[5] = new Array("You see nothing like this in my country!", "Ben, New York", "6");
content[6] = new Array("The people are so friendly!", "Vanessa, Africa", "7");
content[7] = new Array("Theara is amazing!", "Lionel, Russia", "8");
content[8] = new Array("When in doubt come to Cambodia", "Davin, Brookyln", "9");
content[9] = new Array("Beautiful country, lovely scenery", "Davin, Brookyln", "10");



function changeJumbo(){
    var i =  Math.floor(Math.random() * content.length) + 1;
   
    var jumcontent = "";
    var jumadvocate = "";
    var advocatenum = "";
    
    
    jumcontent +=  content[i][0];
    jumadvocate += content[i][1];
    advocatenum +=  content[i][2]+ " / " + content.length;
    
    document.getElementById("jumcontent").innerHTML = jumcontent;
    document.getElementById("jumadvocate").innerHTML = jumadvocate;
    document.getElementById("advocatenum").innerHTML = advocatenum;
    return;
}


$(document).ready(function () {
 
window.setTimeout(function() {
    $(".alert").fadeTo(1000, 0).slideUp(1000, function(){
        $(this).remove(); 
    });
}, 5000);
 
});

